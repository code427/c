#include <dbus/dbus.h>
#include <dbus/dbus-glib.h>
#include <stdlib.h>
#include <stdio.h>

/*
cc $(pkg-config --cflags --libs dbus-glib-1) -o dbus-send-reply dbus-send-reply.c && echo "---Compiled Successfully---" && ./dbus-send-reply
*/

static void
add_three_ints (DBusMessage *message, DBusConnection *connection)
{
	DBusError dberr;
	DBusMessage *reply;
	dbus_uint32_t arg1, arg2, arg3, result;

	dbus_error_init (&dberr);
	dbus_message_get_args (message, &dberr, DBUS_TYPE_INT32, &arg1, DBUS_TYPE_INT32, &arg2, DBUS_TYPE_INT32, &arg3, DBUS_TYPE_INVALID);

	if (dbus_error_is_set (&dberr)) {
		reply = dbus_message_new_error_printf (message, "WrongArguments", "%s", dberr.message);
		dbus_error_free (&dberr);
		if (reply == NULL) {
			fprintf (stderr, "Could not create reply for message!");
			exit (1);
		}
	} else {
		result = arg1 + arg2 + arg3;

		reply = dbus_message_new_method_return (message);
		if (reply == NULL) {
			fprintf (stderr, "Could not create reply for message!");
			exit (1);
		}

		dbus_message_append_args (reply, DBUS_TYPE_INT32, &result, DBUS_TYPE_INVALID);
	}

	dbus_connection_send (connection, reply, NULL);

	dbus_message_unref (reply);
}

static DBusHandlerResult
filter_func (DBusConnection *connection,
             DBusMessage *message,
             void *user_data)
{
	dbus_bool_t handled = FALSE;

	if (dbus_message_is_method_call (message, "com.aillon.test", "add_three_ints")) {
		printf ("Handling method call\n");
		add_three_ints (message, connection);
		handled = TRUE;
	}

	return (handled ? DBUS_HANDLER_RESULT_HANDLED : DBUS_HANDLER_RESULT_NOT_YET_HANDLED);
}

int main (int argc, char *argv[])
{
	DBusError dberr;
	DBusConnection *dbconn;

	dbus_error_init (&dberr);
	dbconn = dbus_bus_get (DBUS_BUS_SESSION, &dberr);

	if (dbus_error_is_set (&dberr)) {
		fprintf (stderr, "getting session bus failed: %s\n", dberr.message);
		dbus_error_free (&dberr);
		return EXIT_FAILURE;
	}

	dbus_bus_request_name (dbconn, "com.aillon.test",
	                       DBUS_NAME_FLAG_REPLACE_EXISTING, &dberr);
	if (dbus_error_is_set (&dberr)) {
		fprintf (stderr, "requesting name failed: %s\n", dberr.message);
		dbus_error_free (&dberr);
		return EXIT_FAILURE;
	}

	if (!dbus_connection_add_filter (dbconn, filter_func, dbconn, NULL))
		return EXIT_FAILURE;

	while (dbus_connection_read_write_dispatch (dbconn, -1))
		; /* empty loop body */


	return EXIT_SUCCESS;
}
