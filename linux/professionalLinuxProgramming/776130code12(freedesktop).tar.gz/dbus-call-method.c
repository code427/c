#include <dbus/dbus.h>
#include <dbus/dbus-glib.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

/*
cc $(pkg-config --cflags --libs dbus-glib-1) -o dbus-call-method dbus-call-method.c && echo "---Compiled Successfully---" && ./dbus-call-method
*/

int main (int argc, char *argv[])
{
	DBusError dberr;
	DBusConnection *dbconn;
	DBusMessage *dbmsg, *dbreply;
	DBusMessageIter dbiter;
	int arg1, arg2, arg3, result;
	struct tm *cur_time;
	time_t cur_time_t;

	dbus_error_init (&dberr);
	dbconn = dbus_bus_get (DBUS_BUS_SESSION, &dberr);
	if (dbus_error_is_set (&dberr)) {
		fprintf (stderr, "getting session bus failed: %s\n", dberr.message);
		dbus_error_free (&dberr);
		return EXIT_FAILURE;
	}

	dbmsg = dbus_message_new_method_call ("com.aillon.test",
	                                      "/com/aillon/test",
	                                      "com.aillon.test",
	                                      "add_three_ints");
	if (dbmsg == NULL) {
		fprintf (stderr, "Couldn't create a DBusMessage");
		return EXIT_FAILURE;
	}

	cur_time_t = time (NULL);
	cur_time = localtime (&cur_time_t);
	arg1 = cur_time->tm_hour;
	arg2 = cur_time->tm_min;
	arg3 = cur_time->tm_sec;

	dbus_message_iter_init_append (dbmsg, &dbiter);
	dbus_message_iter_append_basic (&dbiter, DBUS_TYPE_INT32, &arg1);
	dbus_message_iter_append_basic (&dbiter, DBUS_TYPE_INT32, &arg2);
	dbus_message_iter_append_basic (&dbiter, DBUS_TYPE_INT32, &arg3);

	printf ("Calling add_three_ints method\n");
	dbus_error_init (&dberr);
	dbreply = dbus_connection_send_with_reply_and_block (dbconn, dbmsg, 5000, &dberr);
	if (dbus_error_is_set (&dberr)) {
		fprintf (stderr, "Error getting a reply: %s!", dberr.message);
		dbus_message_unref (dbmsg);
		dbus_error_free (&dberr);
		return EXIT_FAILURE;
	}

	/* Don't need this anymore */
	dbus_message_unref (dbmsg);


	dbus_error_init (&dberr);
	dbus_message_get_args (dbreply, &dberr, DBUS_TYPE_INT32, &result);
	if (dbus_error_is_set (&dberr)) {
		fprintf (stderr, "Error getting the result: %s!", dberr.message);
		dbus_message_unref (dbmsg);
		dbus_error_free (&dberr);
		return EXIT_FAILURE;
	}

	printf ("Result of : add_three_ints (%d, %d, %d) is %d\n", arg1, arg2, arg3, result);

	dbus_message_unref (dbreply);

	dbus_connection_unref (dbconn);

	return EXIT_SUCCESS;
}


