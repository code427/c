#include <libhal.h>
#include <stdlib.h>
#include <stdio.h>

/* Compiling with:
cc $(pkg-config --cflags --libs hal) -o hal-optical-test hal-optical-test.c && ./hal-optical-test
*/


int main (int argc, char *argv[])
{
	DBusConnection *dbconn;
	DBusError dberr;

	LibHalContext *hal_ctx;
	LibHalPropertyType property_type;
	char *property_key;
	dbus_bool_t bool_value;
	int int_value;
	char **udis;
	int num_udis;
	int i;

	dbus_error_init (&dberr);
	dbconn = dbus_bus_get (DBUS_BUS_SYSTEM, &dberr);
	if (dbus_error_is_set (&dberr)) {
		fprintf (stderr, "Can't get D-Bus system bus!");
		return EXIT_FAILURE;
	}

	hal_ctx = libhal_ctx_new ();
	if (hal_ctx == NULL) {
		fprintf (stderr, "Can't create a LibHalContext!");
		return EXIT_FAILURE;
	}

	/* Associate HAL with the D-Bus connection we established */ 
	libhal_ctx_set_dbus_connection (hal_ctx, dbconn);

	dbus_error_init (&dberr);
	libhal_ctx_init (hal_ctx, &dberr);
	if (dbus_error_is_set (&dberr)) {
		fprintf (stderr, "libhal_ctx_init() failed: '%s'.  Is hald running?",
		                  dberr.message);
		dbus_error_free (&dberr);
		libhal_ctx_free (hal_ctx);
		return EXIT_FAILURE;
	}

	/* Looking for optical drives: storage.cdrom is the capability */
	udis = libhal_find_device_by_capability (hal_ctx, "storage.cdrom", &num_udis, &dberr);
	if (dbus_error_is_set (&dberr)) {
		fprintf (stderr, "libhal_find_device_by_capability error: '%s'\n", dberr.message);
		dbus_error_free (&dberr);
		libhal_ctx_free (hal_ctx);
		return EXIT_FAILURE;
	}

	printf ("Found %d Optical Device(s)\n", num_udis);
	for (i = 0; i < num_udis; i++) {
		/* Ensure our properties are the expected type */
		property_type = libhal_device_get_property_type (hal_ctx,
		                                                 udis[i],
		                                                 "storage.cdrom.dvd",
		                                                 &dberr);
		if (dbus_error_is_set (&dberr) || property_type != LIBHAL_PROPERTY_TYPE_BOOLEAN) {
			fprintf (stderr, "error checking storage.cdrom.dvd type");
			dbus_error_free (&dberr);
			libhal_ctx_free (hal_ctx);
			return EXIT_FAILURE;
		}

		property_type = libhal_device_get_property_type (hal_ctx,
		                                                 udis[i],
		                                                 "storage.cdrom.read_speed",
		                                                 &dberr);
		if (dbus_error_is_set (&dberr) || property_type != LIBHAL_PROPERTY_TYPE_INT32) {
			fprintf (stderr, "error checking storage.cdrom.read_speed type");
			dbus_error_free (&dberr);
			libhal_ctx_free (hal_ctx);
			return EXIT_FAILURE;
		}

		/* Okay, now simply get property values */
		bool_value = libhal_device_get_property_bool (hal_ctx, udis[i],
		                                                "storage.cdrom.dvd",
		                                                &dberr);
		if (dbus_error_is_set (&dberr)) {
			fprintf (stderr, "error getting storage.cdrom.dvd");
			dbus_error_free (&dberr);
			libhal_ctx_free (hal_ctx);
			return EXIT_FAILURE;
		}
		int_value = libhal_device_get_property_int (hal_ctx, udis[i],
		                                            "storage.cdrom.read_speed",
		                                            &dberr);                                            
		if (dbus_error_is_set (&dberr)) {
			fprintf (stderr, "error getting storage.cdrom.dvd");
			dbus_error_free (&dberr);
			libhal_ctx_free (hal_ctx);
			return EXIT_FAILURE;
		}

		/* Display the info we just got */
		printf ("Device %s has a maximum read spead of %d kb/s and %s read DVDs.\n",
		        udis[i], int_value, bool_value ? "can" : "cannot");
	}

	return EXIT_SUCCESS;
}
