#include <libhal.h>
#include <dbus/dbus.h>
#include <dbus/dbus-glib.h>
#include <glib.h>
#include <stdlib.h>
#include <stdio.h>

/*
cc $(pkg-config --cflags --libs hal dbus-glib-1) -o halloworld halloworld.c && ./halloworld
*/

static void all_done (LibHalContext *hal_ctx)
{
	DBusError dberr;
	GMainLoop *mainloop;

	mainloop = (GMainLoop*) libhal_ctx_get_user_data (hal_ctx);

	dbus_error_init (&dberr);
	libhal_ctx_shutdown (hal_ctx, &dberr);
	if (dbus_error_is_set (&dberr)) {
		fprintf (stderr, "libhal shutdown failed: '%s'", dberr.message);
		dbus_error_free (&dberr);
	}
	libhal_ctx_free (hal_ctx);

	g_main_loop_quit (mainloop);
}

static void my_device_added_callback (LibHalContext *hal_ctx, const char *udi)
{
	printf ("Device added: '%s'\n", udi);

	all_done (hal_ctx);
}

static void my_device_removed_callback (LibHalContext *hal_ctx, const char *udi)
{
	printf ("Device removed: '%s'\n", udi);

	all_done (hal_ctx);
}

int main (int argc, char *argv[])
{
	GMainLoop *mainloop;

	DBusConnection *dbconn;
	DBusError dberr;

	LibHalContext *hal_ctx;

	mainloop = g_main_loop_new (NULL, FALSE);
	if (mainloop == NULL) {
		fprintf (stderr, "Can't get a mainloop");
		return EXIT_FAILURE;
	}

	dbus_error_init (&dberr);
	dbconn = dbus_bus_get (DBUS_BUS_SYSTEM, &dberr);
	if (dbus_error_is_set (&dberr)) {
		fprintf (stderr, "Can't get D-Bus system bus!");
		return EXIT_FAILURE;
	}

	dbus_connection_setup_with_g_main (dbconn, NULL);

	hal_ctx = libhal_ctx_new ();
	if (hal_ctx == NULL) {
		fprintf (stderr, "Can't create a LibHalContext!");
		return EXIT_FAILURE;
	}

	/* Associate HAL with the D-Bus connection we established */ 
	libhal_ctx_set_dbus_connection (hal_ctx, dbconn);
	/* Register callbacks */
	libhal_ctx_set_device_added (hal_ctx, my_device_added_callback);
	libhal_ctx_set_device_removed (hal_ctx, my_device_removed_callback);
	/* We will be breaking out of the mainloop in a callback */
	libhal_ctx_set_user_data (hal_ctx, mainloop);

	dbus_error_init (&dberr);
	libhal_device_property_watch_all (hal_ctx, &dberr);
	if (dbus_error_is_set (&dberr)) {
		fprintf (stderr, "libhal_device_property_watch_all() failed: '%s'", dberr.message);
		dbus_error_free (&dberr);
		libhal_ctx_free (hal_ctx);
		return EXIT_FAILURE;
	}

	dbus_error_init (&dberr);
	libhal_ctx_init (hal_ctx, &dberr);
	if (dbus_error_is_set (&dberr)) {
		fprintf (stderr, "libhal_ctx_init() failed: '%s'.  Is hald running?",
		                  dberr.message);
		dbus_error_free (&dberr);
		libhal_ctx_free (hal_ctx);
		return EXIT_FAILURE;
	}

	g_main_loop_run (mainloop);

	return EXIT_SUCCESS;
}
